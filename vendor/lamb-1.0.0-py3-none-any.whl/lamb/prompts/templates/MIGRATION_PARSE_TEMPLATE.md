### ROLE & OBJECTIVE
You are an expert static code analysis engine. Your goal is to extract all API symbols—namespaces/modules, types/containers, standalone functions/constants, and member accesses (methods, properties, fields, enum variants)—referenced in the provided code snippet as structured `(namespace, class_or_interface, member)` entries, plus any undeclared/external variables or untyped parameters whose types cannot be determined from the snippet.

### INSTRUCTIONS & GUIDELINES
1. **Structured 3-Field Tuple (`namespace`, `class_or_interface`, `member`):**
    - **`namespace`**: Standardize all namespace, package, or module paths to **dot notation (`.`)** across all programming languages (convert `::`, `->`, `/`, `\`, `#` to `.`, e.g., `Database::Core` -> `Database.Core`, `std` -> `std`). Leave as `""` if global or unknown.
    - **`class_or_interface`**: Extract strictly the unqualified class, interface, struct, trait, or enum name (e.g., `QueryEngine`, `Vector2`, `DataFrame`). Never include namespace prefixes or local variable names (like `df`, `u`, `velocity`, `body`) here. Leave as `""` for standalone functions/constants, namespace-only references, or when the receiver's type is genuinely unknown.
    - **`member`**: Extract strictly the unqualified method, function, property, field, constant, or enum variant name (e.g., `executeQuery`, `y`, `shape`). Leave as `""` if the entry represents the container or namespace itself.
2. **Entry Granularity:**
    - **Explicit Namespace Imports/Declarations:** Emit `("namespace", "", "")` when a namespace/module itself is imported or declared.
    - **Type / Container References:** Emit `("namespace", "ClassOrInterface", "")` for imported types, type annotations, instantiations, base classes (`extends` / inheritance), and static/enum references.
    - **Standalone Functions / Constants / Globals:** Emit `("namespace", "", "member")` with `class_or_interface` as `""`.
    - **Member Calls / Property Accesses:** Emit `("namespace", "ClassOrInterface", "member")`, resolving local variable receiver types when evident from declarations, constructors, type annotations, casts, imports, or class inheritance. If the receiver's type is genuinely unknown, emit `("", "", "member")`.
3. **Never Guess or Fallback-Echo:**
    - Use `""` for any unknown or non-applicable field. Do NOT invent type names and do NOT copy `member` or `class_or_interface` into `namespace`.
4. **Untyped / External Symbols (`untyped_symbols`):**
    - For every undeclared/external variable or untyped parameter whose type cannot be determined from the snippet, add an entry `{"symbol_name": "...", "accessed_members": [...]}` listing all attributes, properties, and methods accessed on it, and also emit `{"namespace": "", "class_or_interface": "", "member": "<m>"}` in `identifiers` for each accessed member.
5. **Exclude Pure Local Variable Names:**
    - Do not emit local variable or parameter names themselves as `identifiers`.

### OUTPUT FORMATTING

```json
{
    "identifiers": [
        {
            "namespace": "Dot-normalized namespace or ''",
            "class_or_interface": "Unqualified container/type name or ''",
            "member": "Unqualified member/function/property/constant name or ''"
        }
    ],
    "untyped_symbols": [
        {
            "symbol_name": "Untyped or undeclared symbol name",
            "accessed_members": ["member_or_property_1", "method_2"]
        }
    ]
}
```

### EXAMPLES

**Example 1: Python Data Processing Script**

**Input:**

```python
import pandas as pd
from typing import List, Optional
from mymodule.models import UserProfile

def process_users(users: List[UserProfile], default_id: Optional[int]) -> pd.DataFrame:
    raw_data = [u.to_dict() for u in users]
    df: pd.DataFrame = pd.DataFrame(raw_data)
    print(f"Total rows: {df.shape[0]}")
    return df
```

**Output:**

```json
{
    "identifiers": [
        {"namespace": "typing", "class_or_interface": "List", "member": ""},
        {"namespace": "mymodule.models", "class_or_interface": "UserProfile", "member": ""},
        {"namespace": "typing", "class_or_interface": "Optional", "member": ""},
        {"namespace": "builtins", "class_or_interface": "int", "member": ""},
        {"namespace": "pandas", "class_or_interface": "DataFrame", "member": ""},
        {"namespace": "", "class_or_interface": "", "member": "process_users"},
        {"namespace": "mymodule.models", "class_or_interface": "UserProfile", "member": "to_dict"},
        {"namespace": "builtins", "class_or_interface": "", "member": "print"},
        {"namespace": "pandas", "class_or_interface": "DataFrame", "member": "shape"}
    ],
    "untyped_symbols": []
}
```

---

**Example 2: Java Service Class**

**Input:**

```java
package com.example.service;

import java.util.Map;
import com.example.model.Order;

public class OrderProcessor {
    private final Map<String, Order> activeOrders;

    public OrderProcessor(Map<String, Order> orders) {
        this.activeOrders = orders;
    }

    public int getOrderCount() {
        return this.activeOrders.size();
    }
}
```

**Output:**

```json
{
    "identifiers": [
        {"namespace": "com.example.service", "class_or_interface": "OrderProcessor", "member": ""},
        {"namespace": "java.util", "class_or_interface": "Map", "member": ""},
        {"namespace": "java.lang", "class_or_interface": "String", "member": ""},
        {"namespace": "com.example.model", "class_or_interface": "Order", "member": ""},
        {"namespace": "", "class_or_interface": "int", "member": ""},
        {"namespace": "com.example.service", "class_or_interface": "OrderProcessor", "member": "getOrderCount"},
        {"namespace": "com.example.service", "class_or_interface": "OrderProcessor", "member": "activeOrders"},
        {"namespace": "java.util", "class_or_interface": "Map", "member": "size"}
    ],
    "untyped_symbols": []
}
```

---

**Example 3: TypeScript Request Handler**

**Input:**

```typescript
import { Request, Response } from 'express';

interface AuthenticatedRequest extends Request {
    userRole: string;
}

export function handleRequest(req: AuthenticatedRequest, res: Response): void {
    const role = req.userRole;
    res.status(200).send({ role: role });
}
```

**Output:**

```json
{
    "identifiers": [
        {"namespace": "express", "class_or_interface": "Request", "member": ""},
        {"namespace": "express", "class_or_interface": "Response", "member": ""},
        {"namespace": "", "class_or_interface": "AuthenticatedRequest", "member": ""},
        {"namespace": "", "class_or_interface": "string", "member": ""},
        {"namespace": "", "class_or_interface": "void", "member": ""},
        {"namespace": "", "class_or_interface": "AuthenticatedRequest", "member": "userRole"},
        {"namespace": "", "class_or_interface": "", "member": "handleRequest"},
        {"namespace": "express", "class_or_interface": "Response", "member": "status"},
        {"namespace": "express", "class_or_interface": "Response", "member": "send"}
    ],
    "untyped_symbols": []
}
```

---

**Example 4: C++ Database Query Routine**

**Input:**

```cpp
#include <iostream>
#include <vector>
#include <string>

namespace Database {
    namespace Core {
        class QueryEngine {
            public:
                std::vector<std::string> executeQuery(const std::string& sql);
        };
    }
}

void logAndQuery(Database::Core::QueryEngine& engine, const std::string& sql) {
    std::clog << sql << std::endl;
    engine.executeQuery(sql);
}
```

**Output:**

```json
{
    "identifiers": [
        {"namespace": "Database.Core", "class_or_interface": "", "member": ""},
        {"namespace": "Database.Core", "class_or_interface": "QueryEngine", "member": ""},
        {"namespace": "std", "class_or_interface": "vector", "member": ""},
        {"namespace": "std", "class_or_interface": "string", "member": ""},
        {"namespace": "", "class_or_interface": "", "member": "logAndQuery"},
        {"namespace": "Database.Core", "class_or_interface": "QueryEngine", "member": "executeQuery"},
        {"namespace": "std", "class_or_interface": "", "member": "clog"},
        {"namespace": "std", "class_or_interface": "", "member": "endl"}
    ],
    "untyped_symbols": []
}
```

---

**Example 5: GDScript Player Script with Local Type Inference & Untyped Parameter**

**Input:**

```gdscript
extends KinematicBody2D

var velocity = Vector2()

func _physics_process(delta):
    velocity.y += 980.0 * delta
    velocity = move_and_slide(velocity, Vector2.UP)

func on_hit(body):
    if body.get_collider():
        body.apply_impulse(Vector2.ZERO, Vector2(0, -100))
```

**Output:**

```json
{
    "identifiers": [
        {"namespace": "", "class_or_interface": "KinematicBody2D", "member": ""},
        {"namespace": "", "class_or_interface": "Vector2", "member": ""},
        {"namespace": "", "class_or_interface": "Vector2", "member": "y"},
        {"namespace": "", "class_or_interface": "Vector2", "member": "UP"},
        {"namespace": "", "class_or_interface": "Vector2", "member": "ZERO"},
        {"namespace": "", "class_or_interface": "KinematicBody2D", "member": "move_and_slide"},
        {"namespace": "", "class_or_interface": "", "member": "get_collider"},
        {"namespace": "", "class_or_interface": "", "member": "apply_impulse"}
    ],
    "untyped_symbols": [
        {
            "symbol_name": "body",
            "accessed_members": ["get_collider", "apply_impulse"]
        }
    ]
}
```

### INPUT DATA