"""
Deterministic, language-agnostic Exact-Match Anchoring for API element mapping.

Before any statistical matching, this module locks in V1 -> V2 pairs that can be
identified with certainty from names and signatures alone. Anchored pairs are
removed from the candidate pools, so the downstream scoring pipeline only has to
deal with elements that actually changed.

The pass is a cascading sieve. Each tier only sees what earlier tiers left over,
and every tier requires a strictly bijective (1:1) match on both sides:

    Tier 1 - Verbatim:      identical (namespace, class, member, signature text).
    Tier 2 - Canonical:     identical after identifier normalization
                            (camelCase / snake_case / kebab-case / ...) and
                            identical language-agnostic signature profiles.
    Tier 3 - Compatible:    same canonical FQN, backward-compatible signature
                            change (e.g. new optional parameters). Overloads are
                            resolved only when the compatibility is mutually unique.
    Tier 4 - Relocated:     same canonical (class, member, profile), different
                            namespace, unique across the *entire* V1 and V2 sets.
    Tier 5 - Translated:    Tiers 2 and 3 again, after translating V1 namespaces
                            that disappeared in V2 through the relocations found
                            in Tier 4.

Only the Python standard library is used.
"""

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple


# --------------------------------------------------------------------------- #
# Identifier Normalization
# --------------------------------------------------------------------------- #

_WORD_DELIMITERS = re.compile(r"[\W_]+", re.UNICODE)
_PATH_SEPARATORS = re.compile(r"::|->|[./\\#]")


def _char_class(ch: str) -> str:
    if ch.isdigit():
        return "d"
    if ch.isupper():
        return "u"
    if ch.islower():
        return "l"

    # Caseless letters (e.g. CJK) behave like lowercase for boundary detection
    return "l"


def _split_case_chunk(chunk: str) -> List[str]:
    """Splits a delimiter-free chunk on case and letter/digit transitions."""

    words = []
    start = 0
    n = len(chunk)

    for i in range(1, n):
        prev, cur = _char_class(chunk[i - 1]), _char_class(chunk[i])

        if (cur == "d") != (prev == "d"):
            boundary = True                                   # 'utf8' -> 'utf' | '8'
        elif prev == "l" and cur == "u":
            boundary = True                                   # 'getUser' -> 'get' | 'User'
        elif prev == "u" and cur == "u" and i + 1 < n and _char_class(chunk[i + 1]) == "l":
            boundary = True                                   # 'HTTPResponse' -> 'HTTP' | 'Response'
        else:
            boundary = False

        if boundary:
            words.append(chunk[start:i])
            start = i

    words.append(chunk[start:])

    return words


def split_identifier(name: str) -> Tuple[str, ...]:
    """
    Decomposes an identifier into lowercase sub-words, independent of naming convention.

    'getUserProfile', 'GetUserProfile', 'get_user_profile', 'get-user-profile',
    'GET_USER_PROFILE' and '_getUserProfile$' all yield ('get', 'user', 'profile').
    """

    if not name:
        return ()

    tokens: List[str] = []

    for chunk in _WORD_DELIMITERS.split(name):
        if chunk:
            tokens.extend(_split_case_chunk(chunk))

    return tuple(token.casefold() for token in tokens if token)


def canonical_identifier(name: str) -> str:
    return "_".join(split_identifier(name))


def canonical_path(path: str) -> Tuple[str, ...]:
    """
    Canonicalizes a hierarchical path ('Game::Networking', 'my_pkg.http_utils')
    segment by segment, preserving segment boundaries so that 'a.b_c' != 'a_b.c'.
    """

    if not path:
        return ()

    segments = (canonical_identifier(segment) for segment in _PATH_SEPARATORS.split(path))

    return tuple(segment for segment in segments if segment)


# --------------------------------------------------------------------------- #
# Low-Level Scanning Helpers (bracket- and quote-aware)
# --------------------------------------------------------------------------- #

_OPEN_TO_CLOSE = {"(": ")", "[": "]", "{": "}"}
_CLOSERS = set(_OPEN_TO_CLOSE.values())
_LIFETIME = re.compile(r"'[A-Za-z_]\w*")


def _skip_quote(text: str, i: int) -> int:
    """
    Given text[i] is a quote character, returns the index just past the literal.
    Rust lifetimes ('a, 'static) are not treated as quotes.
    """

    quote = text[i]

    if quote == "'":
        lifetime = _LIFETIME.match(text, i)

        if lifetime and (lifetime.end() >= len(text) or text[lifetime.end()] != "'"):
            return lifetime.end()

    j = i + 1

    while j < len(text):
        if text[j] == "\\":
            j += 2

            continue

        if text[j] == quote:
            return j + 1

        j += 1

    # Unterminated literal: treat the quote as a plain character
    return i + 1


def _find_matching(text: str, open_index: int) -> int:
    """Returns the index of the bracket closing text[open_index], or -1."""

    stack = [_OPEN_TO_CLOSE[text[open_index]]]
    i = open_index + 1

    while i < len(text):
        ch = text[i]

        if ch in "'\"`":
            i = _skip_quote(text, i)

            continue

        if ch in _OPEN_TO_CLOSE:
            stack.append(_OPEN_TO_CLOSE[ch])
        elif ch in _CLOSERS:
            if ch != stack[-1]:
                return -1

            stack.pop()

            if not stack:
                return i

        i += 1

    return -1


def _skip_angle_group(text: str, open_index: int) -> int:
    """Given text[open_index] == '<', returns the index just past the matching '>', or -1."""

    depth = 0
    i = open_index

    while i < len(text):
        ch = text[i]

        if ch == "<":
            depth += 1
        elif ch == ">" and text[i - 1] not in "-=":
            depth -= 1

            if depth == 0:
                return i + 1
        elif ch in "(){};":
            return -1

        i += 1

    return -1


def _split_top_level(text: str, separator: str = ",", track_angles: bool = True) -> Optional[List[str]]:
    """
    Splits on `separator` only at bracket depth 0. Returns None when angle brackets
    turn out to be unbalanced (e.g. a '<' comparison inside a default value).
    """

    parts = []
    depth = 0
    angle = 0
    start = 0
    i = 0

    while i < len(text):
        ch = text[i]

        if ch in "'\"`":
            i = _skip_quote(text, i)

            continue

        if ch in _OPEN_TO_CLOSE:
            depth += 1
        elif ch in _CLOSERS:
            depth -= 1
        elif track_angles and ch == "<":
            angle += 1
        elif track_angles and ch == ">" and i > 0 and text[i - 1] not in "-=":
            angle -= 1

            if angle < 0:
                return None
        elif ch == separator and depth == 0 and angle == 0:
            parts.append(text[start:i])
            start = i + 1

        i += 1

    if track_angles and angle != 0:
        return None

    parts.append(text[start:])

    return parts


def _find_top_level_char(text: str, target: str) -> int:
    """
    Finds the first depth-0 occurrence of a single-character operator, skipping
    multi-character operators ('::', '==', '=>', '<=', '>=', '!=', ':=').
    """

    depth = 0
    angle = 0
    i = 0

    while i < len(text):
        ch = text[i]

        if ch in "'\"`":
            i = _skip_quote(text, i)

            continue

        if ch in _OPEN_TO_CLOSE:
            depth += 1
        elif ch in _CLOSERS:
            depth -= 1
        elif ch == "<":
            angle += 1
        elif ch == ">" and i > 0 and text[i - 1] not in "-=":
            angle = max(0, angle - 1)
        elif ch == target and depth == 0 and angle == 0:
            prev_ch = text[i - 1] if i > 0 else ""
            next_ch = text[i + 1] if i + 1 < len(text) else ""

            if target == ":" and (prev_ch == ":" or next_ch in ":="):
                pass
            elif target == "=" and (next_ch in "=>" or prev_ch in "=<>!:"):
                pass
            else:
                return i

        i += 1

    return -1


# --------------------------------------------------------------------------- #
# Language-Agnostic Signature Canonization
# --------------------------------------------------------------------------- #

_HTTP_ROUTE = re.compile(r"^\s*(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS|TRACE|CONNECT)\s+(\S+)", re.IGNORECASE)
_ROUTE_PARAM = re.compile(r"^(?:\{[^}]*\}|:\w+\??|<[^>]*>|\[[^\]]*\]|\$\w+)$")
_DECORATOR_NAME = re.compile(r"@[\w.$:]*")
_PARAM_ANNOTATION = re.compile(r"^@[\w.$]+(?:\s*\([^)]*\))?\s*")

# Keywords that may directly precede a '(' without it being a parameter list
# (e.g. Go method receivers: `func (c *Client) Fetch(...)`).
_DECLARATION_KEYWORDS = {
    "func", "fn", "def", "fun", "function", "sub", "proc", "lambda",
    "operator", "if", "for", "while", "switch", "return", "sizeof", "typeof",
}

# Modifiers that can prefix a single parameter declaration in various languages
_PARAM_MODIFIERS = {
    "const", "final", "ref", "out", "in", "inout", "params", "vararg", "readonly",
    "public", "private", "protected", "internal", "mut", "var", "val", "let",
    "override", "required", "scoped", "volatile", "register", "restrict",
    "noalias", "crossinline", "noinline", "borrowing", "consuming", "owned",
}

_VARIADIC_MODIFIERS = {"params", "vararg"}
_RECEIVER_PATTERN = re.compile(r"^(?:self|cls|this)\b")


@dataclass(frozen=True)
class Parameter:
    name: str
    optional: bool = False
    variadic: bool = False


@dataclass(frozen=True)
class SignatureProfile:
    """
    Language-agnostic structural fingerprint of a signature.

    kind:
        'callable' - has a parameter list.
        'route'    - an HTTP route ('GET /users/{id}').
        'value'    - anything else (constants, fields, containers, enum variants).

    Parameter *types* and return types are deliberately excluded: they are
    language-specific and often change cosmetically between versions.
    """

    kind: str
    params: Tuple[Parameter, ...] = ()
    http_method: str = ""
    route: str = ""

    @property
    def required_arity(self) -> int:
        return sum(1 for p in self.params if not (p.optional or p.variadic))

    @property
    def total_arity(self) -> int:
        return len(self.params)

    @property
    def has_varargs(self) -> bool:
        return any(p.variadic for p in self.params)

    def key(self) -> tuple:
        return (self.kind, self.http_method, self.route, self.params)


def normalize_signature_text(signature: str) -> str:
    """Whitespace-insensitive form of the raw signature (used by Tier 1)."""

    text = re.sub(r"\s+", " ", signature or "").strip().rstrip(";").strip()

    return re.sub(r"\s*([()\[\]{}<>,:;=*&|.?!])\s*", r"\1", text)


def _strip_leading_decorators(signature: str) -> str:
    """Removes leading decorators / annotations / attributes (@x, @x(...), [Attr], #[attr])."""

    text = signature.lstrip()

    while text:
        if text.startswith("@"):
            end = _DECORATOR_NAME.match(text).end()

            if end < len(text) and text[end] == "(":
                close = _find_matching(text, end)

                if close == -1:
                    break

                end = close + 1

            text = text[end:].lstrip()
        elif text.startswith("#[") or text.startswith("["):
            open_index = 1 if text[0] == "#" else 0
            close = _find_matching(text, open_index)

            if close == -1:
                break

            text = text[close + 1:].lstrip()
        else:
            break

    return text


def _first_word(text: str) -> str:
    match = re.match(r"\s*([A-Za-z_]\w*)", text)

    return match.group(1).lower() if match else ""


def _is_identifier_char(ch: str) -> bool:
    return ch.isalnum() or ch in "_$"


def _locate_parameter_group(signature: str, member: str) -> Optional[Tuple[int, int]]:
    """Returns (open, close) indices of the parameter list's parentheses, if any."""

    # 1. Anchored on the member name: `name(`, `name <T>(`
    if member:
        for match in re.finditer(re.escape(member), signature):
            start = match.start()

            if start > 0 and _is_identifier_char(signature[start - 1]):
                continue

            j = match.end()

            if j < len(signature) and _is_identifier_char(signature[j]):
                continue

            while j < len(signature) and signature[j].isspace():
                j += 1

            if j < len(signature) and signature[j] == "<":
                j = _skip_angle_group(signature, j)

                if j == -1:
                    continue

                while j < len(signature) and signature[j].isspace():
                    j += 1

            if j < len(signature) and signature[j] == "(":
                close = _find_matching(signature, j)

                if close != -1:
                    return j, close

    # 2. Fallback: the first '(' that directly follows an identifier-like token,
    #    stopping at the first top-level '=' (`MAX = compute(3)` is a value).
    assignment = _find_top_level_char(signature, "=")
    limit = assignment if assignment != -1 else len(signature)
    i = 0

    while i < limit:
        ch = signature[i]

        if ch in "'\"`":
            i = _skip_quote(signature, i)

            continue

        if ch == "(":
            k = i - 1

            while k >= 0 and signature[k].isspace():
                k -= 1

            if k >= 0 and (_is_identifier_char(signature[k]) or signature[k] in ">]?!"):
                word = re.search(r"[\w$]+$", signature[:k + 1])

                if not (word and word.group(0).lower() in _DECLARATION_KEYWORDS):
                    close = _find_matching(signature, i)

                    if close != -1:
                        return i, close

        i += 1

    return None


def _normalize_route(path: str) -> str:
    path = path.split("?", 1)[0].split("#", 1)[0].rstrip("/")
    segments = []

    for segment in path.split("/"):
        if not segment:
            continue

        segments.append("{}" if _ROUTE_PARAM.match(segment) else segment.casefold())

    return "/" + "/".join(segments)


def _parse_parameter(raw: str, go_style: bool) -> Optional[Parameter]:
    """Parses one parameter declaration. Returns None for receivers and pure markers."""

    text = raw.strip()

    if not text or text in ("/", "*"):
        return None                           # Python positional-only / keyword-only markers

    while True:
        stripped = _PARAM_ANNOTATION.sub("", text, count=1)

        if stripped == text:
            break

        text = stripped.strip()

    variadic = False
    optional = False

    # Default value / initializer
    assignment = _find_top_level_char(text, "=")

    if assignment != -1:
        optional = True
        text = text[:assignment].strip()

    # Variadic prefixes: *args, **kwargs, ...rest
    if text.startswith("**") or text.startswith("..."):
        variadic = True
        text = text.lstrip("*.").strip()
    elif text.startswith("*") and not go_style:
        variadic = True
        text = text[1:].strip()

    if not text:
        return Parameter(name="", optional=False, variadic=True) if variadic else None

    # Receivers: self, cls, this, `self: T`, `this: T`, Rust `&self` / `&'a mut self`,
    # C# extension methods `this T x`
    head = re.sub(r"^&\s*(?:'\w+\s+)?", "", text)
    head = re.sub(r"^mut\s+", "", head)

    if _RECEIVER_PATTERN.match(head):
        return None

    # Leading parameter modifiers
    tokens = text.split()

    while len(tokens) > 1 and tokens[0].lower() in _PARAM_MODIFIERS:
        if tokens[0].lower() in _VARIADIC_MODIFIERS:
            variadic = True

        tokens = tokens[1:]

    text = " ".join(tokens)

    if "..." in text:
        variadic = True                       # Java `String... args`, Go `opts ...Option`

    # Name extraction
    colon = _find_top_level_char(text, ":")

    if colon != -1:
        left = text[:colon].strip()

        if left.endswith("?"):
            optional = True                   # TypeScript `timeout?: number`
            left = left[:-1]

        left_words = left.split()
        name = left_words[-1] if left_words else ""
    else:
        parts = _split_top_level(text, " ") or text.split()
        parts = [p for p in parts if p]

        if not parts:
            name = ""
        elif go_style or len(parts) == 1:
            name = parts[0]
        else:
            name = parts[-1]

        if name.endswith("?") and len(parts) == 1:
            optional = True

    name = re.sub(r"\[.*\]$", "", name).strip("*&^%.?!")

    return Parameter(name=canonical_identifier(name), optional=optional, variadic=variadic)


def parse_signature(signature: str, member: str = "") -> SignatureProfile:
    """Builds a language-agnostic SignatureProfile from a raw signature string."""

    text = _strip_leading_decorators(signature or "")

    route = _HTTP_ROUTE.match(text)

    if route:
        return SignatureProfile(kind="route", http_method=route.group(1).upper(), route=_normalize_route(route.group(2)))

    group = _locate_parameter_group(text, member)

    if group is None:
        return SignatureProfile(kind="value")

    open_index, close_index = group
    inner = text[open_index + 1:close_index]
    go_style = _first_word(text) == "func"

    raw_params = _split_top_level(inner, ",", track_angles=True)

    if raw_params is None:
        raw_params = _split_top_level(inner, ",", track_angles=False) or []

    params = []

    for raw in raw_params:
        param = _parse_parameter(raw, go_style)

        if param is not None:
            params.append(param)

    return SignatureProfile(kind="callable", params=tuple(params))


def describe_compatibility(old: SignatureProfile, new: SignatureProfile) -> Optional[str]:
    """
    Checks whether `new` is a backward-compatible evolution of `old`.

    Compatible means: every existing parameter keeps its position, name and
    variadic-ness and does not become required, and every added parameter is
    optional or variadic. Returns a human-readable description of the change
    ('' if the profiles are identical), or None if the change is breaking.
    """

    if old.kind != new.kind:
        return None

    if old.kind != "callable":
        return "" if old.key() == new.key() else None

    if len(new.params) < len(old.params):
        return None

    became_optional = []

    for p_old, p_new in zip(old.params, new.params):
        if p_old.name != p_new.name or p_old.variadic != p_new.variadic:
            return None

        if p_old.optional and not p_new.optional:
            return None

        if p_new.optional and not p_old.optional:
            became_optional.append(p_new.name)

    added = new.params[len(old.params):]

    if any(not (p.optional or p.variadic) for p in added):
        return None

    changes = []

    if added:
        changes.append("added optional parameter(s) " + ", ".join(f"`{p.name or '...'}`" for p in added))

    if became_optional:
        changes.append("parameter(s) " + ", ".join(f"`{name}`" for name in became_optional) + " became optional")

    return "; ".join(changes)


# --------------------------------------------------------------------------- #
# Anchoring Sieve
# --------------------------------------------------------------------------- #

TIER_VERBATIM = 1
TIER_CANONICAL = 2
TIER_COMPATIBLE = 3
TIER_RELOCATED = 4
TIER_TRANSLATED = 5

TIER_NAMES = {
    TIER_VERBATIM: "verbatim",
    TIER_CANONICAL: "canonical",
    TIER_COMPATIBLE: "compatible_evolution",
    TIER_RELOCATED: "relocated",
    TIER_TRANSLATED: "namespace_translated",
}


@dataclass
class _Element:
    index: int
    namespace: str
    class_name: str
    member: str
    signature: str
    text_key: str
    ns_key: Tuple[str, ...]
    class_key: Tuple[str, ...]
    member_key: Tuple[str, ...]
    profile: SignatureProfile

    @property
    def fqn_key(self) -> tuple:
        return (self.ns_key, self.class_key, self.member_key)


@dataclass
class Anchor:
    v1_index: int
    v2_index: int
    tier: int
    note: str = ""

    @property
    def tier_name(self) -> str:
        return TIER_NAMES[self.tier]


@dataclass
class AnchorResult:
    anchors: List[Anchor] = field(default_factory=list)
    residual_v1: List[int] = field(default_factory=list)
    residual_v2: List[int] = field(default_factory=list)

    def stats(self) -> Dict[str, int]:
        counts = Counter(anchor.tier_name for anchor in self.anchors)

        return {name: counts.get(name, 0) for name in TIER_NAMES.values()}


def _prepare(elements: Sequence[dict]) -> List[_Element]:
    prepared = []

    for index, element in enumerate(elements):
        namespace = (element.get("namespace") or "").strip()
        class_name = (element.get("class_or_interface") or "").strip()
        member = (element.get("member") or "").strip()
        signature = element.get("signature") or ""

        prepared.append(_Element(
            index=index,
            namespace=namespace,
            class_name=class_name,
            member=member,
            signature=signature,
            text_key=normalize_signature_text(signature),
            ns_key=canonical_path(namespace),
            class_key=canonical_path(class_name),
            member_key=canonical_path(member),
            profile=parse_signature(signature, member),
        ))

    return prepared


def _is_anchorable(element: _Element) -> bool:
    """Elements without any class or member identity are never auto-anchored."""

    return bool(element.class_key or element.member_key)


def _build_note(old: _Element, new: _Element, signature_change: str = "") -> str:
    """Markdown note describing what changed between two anchored elements (empty if nothing did)."""

    notes = []

    if old.namespace != new.namespace:
        notes.append(f"Namespace changed: `{old.namespace}` → `{new.namespace}`.")

    if old.class_name != new.class_name:
        notes.append(f"Container renamed: `{old.class_name}` → `{new.class_name}`.")

    if old.member != new.member:
        notes.append(f"Member renamed: `{old.member}` → `{new.member}`.")

    if signature_change:
        notes.append(f"Signature evolved: {signature_change}.")

    return " ".join(notes)


class _Sieve:
    def __init__(self, v1: List[_Element], v2: List[_Element]):
        self.v1 = v1
        self.v2 = v2
        self.open_v1 = {e.index for e in v1 if _is_anchorable(e)}
        self.open_v2 = {e.index for e in v2 if _is_anchorable(e)}
        self.anchors: List[Anchor] = []

    def _accept(self, old: _Element, new: _Element, tier: int, signature_change: str = ""):
        self.anchors.append(Anchor(old.index, new.index, tier, _build_note(old, new, signature_change)))
        self.open_v1.discard(old.index)
        self.open_v2.discard(new.index)

    def bijective_pass(self, key_fn, tier: int, key_fn_v2=None, eligible_v1=None, unique_v1=None, unique_v2=None):
        """
        Anchors every key that occurs exactly once among the open V1 elements and
        exactly once among the open V2 elements. `key_fn_v2` overrides the key
        function for V2 (defaults to `key_fn`). Optional `unique_*` counters
        enforce uniqueness against a wider population (e.g. the full sets).
        """

        key_fn_v2 = key_fn_v2 or key_fn
        buckets_v1: Dict[tuple, List[_Element]] = defaultdict(list)
        buckets_v2: Dict[tuple, List[_Element]] = defaultdict(list)

        for element in self.v1:
            if element.index in self.open_v1 and (eligible_v1 is None or eligible_v1(element)):
                key = key_fn(element)

                if key is not None:
                    buckets_v1[key].append(element)

        for element in self.v2:
            if element.index in self.open_v2:
                key = key_fn_v2(element)

                if key is not None:
                    buckets_v2[key].append(element)

        for key, olds in buckets_v1.items():
            news = buckets_v2.get(key)

            if len(olds) != 1 or not news or len(news) != 1:
                continue

            if unique_v1 is not None and unique_v1[key] != 1:
                continue

            if unique_v2 is not None and unique_v2[key] != 1:
                continue

            self._accept(olds[0], news[0], tier)

    def compatible_pass(self, fqn_fn, tier: int):
        """
        Groups open elements by FQN and anchors pairs whose signatures are
        backward compatible, provided the compatibility relation is mutually
        unique inside the group (this also disambiguates overloads).
        """

        groups_v1: Dict[tuple, List[_Element]] = defaultdict(list)
        groups_v2: Dict[tuple, List[_Element]] = defaultdict(list)

        for element in self.v1:
            if element.index in self.open_v1:
                groups_v1[fqn_fn(element)].append(element)

        for element in self.v2:
            if element.index in self.open_v2:
                groups_v2[element.fqn_key].append(element)

        for fqn, olds in groups_v1.items():
            news = groups_v2.get(fqn)

            if not news:
                continue

            compatible: Dict[Tuple[int, int], str] = {}

            for old in olds:
                for new in news:
                    change = describe_compatibility(old.profile, new.profile)

                    if change is not None:
                        compatible[(old.index, new.index)] = change

            partners_v1: Dict[int, List[int]] = defaultdict(list)
            partners_v2: Dict[int, List[int]] = defaultdict(list)

            for old_index, new_index in compatible:
                partners_v1[old_index].append(new_index)
                partners_v2[new_index].append(old_index)

            by_index_v1 = {e.index: e for e in olds}
            by_index_v2 = {e.index: e for e in news}

            for (old_index, new_index), change in compatible.items():
                if partners_v1[old_index] == [new_index] and partners_v2[new_index] == [old_index]:
                    self._accept(by_index_v1[old_index], by_index_v2[new_index], tier, change)


def _relocation_key(element: _Element) -> Optional[tuple]:
    # Very short top-level names ('run', 'get') are too generic to relocate on name alone
    if not element.class_key and sum(len(token) for token in element.member_key) < 4:
        return None

    return (element.class_key, element.member_key, element.profile.key())


def anchor_exact_matches(v1_elements: Sequence[dict], v2_elements: Sequence[dict]) -> AnchorResult:
    """
    Runs the cascading anchoring sieve over two element lists.

    Returns the anchored (v1_index, v2_index) pairs together with the indices of
    the residual elements that still need statistical / LLM-based matching.
    Every anchor is strictly 1:1.
    """

    v1 = _prepare(v1_elements)
    v2 = _prepare(v2_elements)
    sieve = _Sieve(v1, v2)

    # Tier 1 - Verbatim
    sieve.bijective_pass(lambda e: (e.namespace, e.class_name, e.member, e.text_key), TIER_VERBATIM)

    # Tier 2 - Canonical names + identical signature profile
    sieve.bijective_pass(lambda e: (e.fqn_key, e.profile.key()), TIER_CANONICAL)

    # Tier 3 - Canonical names + backward-compatible signature (incl. overloads)
    sieve.compatible_pass(lambda e: e.fqn_key, TIER_COMPATIBLE)

    # Tier 4 - Namespace relocation, unique across the full V1 and V2 sets
    unique_v1 = Counter(k for k in (_relocation_key(e) for e in v1) if k is not None)
    unique_v2 = Counter(k for k in (_relocation_key(e) for e in v2) if k is not None)

    sieve.bijective_pass(
        _relocation_key,
        TIER_RELOCATED,
        unique_v1=unique_v1,
        unique_v2=unique_v2,
    )

    # Tier 5 - Translate namespaces that vanished in V2 via the observed relocations
    v2_namespaces = {e.ns_key for e in v2}
    targets: Dict[Tuple[str, ...], set] = defaultdict(set)
    v1_by_index = {e.index: e for e in v1}
    v2_by_index = {e.index: e for e in v2}

    for anchor in sieve.anchors:
        if anchor.tier == TIER_RELOCATED:
            old_ns = v1_by_index[anchor.v1_index].ns_key
            new_ns = v2_by_index[anchor.v2_index].ns_key

            if old_ns not in v2_namespaces:
                targets[old_ns].add(new_ns)

    translation = {old_ns: next(iter(new_set)) for old_ns, new_set in targets.items() if len(new_set) == 1}

    if translation:
        def translated_fqn(e: _Element) -> tuple:
            return (translation.get(e.ns_key, e.ns_key), e.class_key, e.member_key)

        def is_translated(e: _Element) -> bool:
            return e.ns_key in translation

        sieve.bijective_pass(
            lambda e: (translated_fqn(e), e.profile.key()),
            TIER_TRANSLATED,
            key_fn_v2=lambda e: (e.fqn_key, e.profile.key()),
            eligible_v1=is_translated,
        )

        # Restrict the compatible pass to translated V1 elements by keying the rest out
        sieve.compatible_pass(
            lambda e: translated_fqn(e) if is_translated(e) else ("__untranslated__", e.index),
            TIER_TRANSLATED,
        )

    return AnchorResult(
        anchors=sorted(sieve.anchors, key=lambda a: a.v1_index),
        residual_v1=sorted(sieve.open_v1 | {e.index for e in v1 if not _is_anchorable(e)}),
        residual_v2=sorted(sieve.open_v2 | {e.index for e in v2 if not _is_anchorable(e)}),
    )
