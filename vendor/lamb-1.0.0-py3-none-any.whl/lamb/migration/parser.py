import re
from typing import Set, List, Dict, Optional, Tuple

import tree_sitter_language_pack as tslp
from tree_sitter import Parser, Node

from langchain_core.messages import SystemMessage, HumanMessage

from lamb.core.logging import (
    log_info,
    log_warn,
    log_error
)
from lamb.llm.rate_limited import RateLimitedChatOpenAI
from lamb.core.schemas import (
    Language,
    ParserResult,
    get_supported_languages,
)
from lamb.prompts import (
    get_language_prompt,
    get_parse_prompt,
)
from lamb.core.types import (
    ASTRange,
    ASTSyntaxError
)


_PATH_SEPARATORS = re.compile(r"::|->|[./\\#]")


class SmartParser:
    AVAILABLE_LANGUAGES: list[str] = get_supported_languages()

    def __init__(
        self,
        code: str,
        detector: RateLimitedChatOpenAI,
        analyzer: RateLimitedChatOpenAI,
        language: Optional[str] = "",
        verbose: Optional[bool] = False
    ):
        self.code = code
        self.language = language
        self.verbose = verbose

        self.detector = detector.with_structured_output(Language).with_retry(stop_after_attempt=2)
        self.analyzer = analyzer.with_structured_output(ParserResult).with_retry(stop_after_attempt=2)

        self.tree = None

        self.symbols: Set[Tuple[str, str, str]] = set()
        self.untyped_symbols: Dict[str, List[str]] = {}

        self.parser = None
        self._ast_parsed: bool = False
        self._symbols_extracted: bool = False
        self._symbols_attempted: bool = False


    def _log_info(self, message: str) -> None:
        if self.verbose:
            log_info(message)


    def _log_warn(self, message: str) -> None:
        if self.verbose:
            log_warn(message)


    def _log_error(self, message: str) -> None:
        if self.verbose:
            log_error(message)


    def _detect_language(self) -> str:
        self._log_info("Detecting Programming Language...")

        messages = [
            SystemMessage(content=get_language_prompt(self.AVAILABLE_LANGUAGES)),
            HumanMessage(content=f"\n```\n{self.code}\n```\n")
        ]

        try:
            response = self.detector.invoke(messages)
            detected_lang = response.language.value.strip().lower()

            self._log_info(f"Detected Programming Language is '{detected_lang}'.")

            return detected_lang
        except Exception as E:
            self._log_error(f"Failed Programming Language Detection (Fallback to `python`): {E}")

            return "python"


    def _ensure_language_installed(self) -> bool:
        if not self.language or self.language not in self.AVAILABLE_LANGUAGES:
            self.language = self._detect_language()

        if hasattr(tslp, "downloaded_languages"):
            if self.language in tslp.downloaded_languages():
                return True
        elif tslp.has_language(self.language):
            return True

        self._log_warn(f"Tree-Sitter Grammar Not Found for '{self.language}'.")

        try:
            self._log_info(f"Downloading Tree-Sitter Grammar for '{self.language}'...")
            tslp.download([self.language])
            self._log_info(f"Installed Tree-Sitter Grammar for '{self.language}'.")

            return True
        except Exception as e:
            self._log_error(f"Tree-Sitter Language Grammar Download Failed: {e}")

        return False


    def parse(self, extract_symbols: bool = True) -> bool:
        if not self._ast_parsed:
            self._log_info("Initiating SmartParser Parsing Sequence...")

            if not self._ensure_language_installed():
                self._log_error(f"Failed to Parse Source Code. Tree-Sitter Language Grammar for '{self.language}' Unavailable.")

                return False

            try:
                language_obj = tslp.get_language(self.language)
                self.parser = Parser(language_obj)
                self.tree = self.parser.parse(bytes(self.code, "utf8"))
                self._ast_parsed = True

                self._log_info(f"Tree-Sitter Syntax Tree Construction Completed for '{self.language}'.")
            except Exception as e:
                self._log_error(f"Failed Parsing {self.language}: {e}")

                return False

        if extract_symbols and not self._symbols_extracted:
            if not self._extract_symbols_via_llm():
                return False
            self._symbols_extracted = True
            self._log_info("SmartParser Parsing Sequence Completed.")

        return True


    @staticmethod
    def _split_segments(value: Optional[str]) -> List[str]:
        if not value:
            return []
        return [seg.strip() for seg in _PATH_SEPARATORS.split(value.strip()) if seg.strip()]


    def _extract_symbols_via_llm(self) -> bool:
        self._symbols_attempted = True
        self._log_info("Extracting Identifiers & Untyped Symbol Usages...")

        messages = [
            SystemMessage(content=get_parse_prompt()),
            HumanMessage(content=f"\n```\n{self.code}\n```\n")
        ]

        try:
            response = self.analyzer.invoke(messages)

            for item in response.identifiers:
                ns = ".".join(self._split_segments(item.namespace))
                cls_parts = self._split_segments(item.class_or_interface)
                mem_parts = self._split_segments(item.member)

                if len(cls_parts) > 1:
                    if not ns:
                        ns = ".".join(cls_parts[:-1])
                    cls = cls_parts[-1]
                else:
                    cls = cls_parts[0] if cls_parts else ""

                if len(mem_parts) > 1:
                    if not cls:
                        cls = mem_parts[-2]
                    if not ns and len(mem_parts) > 2:
                        ns = ".".join(mem_parts[:-2])
                    mem = mem_parts[-1]
                else:
                    mem = mem_parts[0] if mem_parts else ""

                if any((ns, cls, mem)):
                    self.symbols.add((ns, cls, mem))

            for untyped in response.untyped_symbols:
                symbol_name = (untyped.symbol_name or "").strip()
                cleaned_members = []
                for raw_member in untyped.accessed_members or []:
                    parts = self._split_segments(raw_member)
                    if parts:
                        cleaned_members.append(parts[-1])

                members = list(dict.fromkeys(cleaned_members))
                if symbol_name and members:
                    self.untyped_symbols[symbol_name] = members

            for members in self.untyped_symbols.values():
                for member in members:
                    if not any(sym[2] == member for sym in self.symbols):
                        self.symbols.add(("", "", member))

            self._log_info(
                f"Extracted {len(self.symbols)} Symbol Tuple(s) and {len(self.untyped_symbols)} Untyped Symbol(s)."
            )
            return True
        except Exception as e:
            self._log_error(f"Identifier Extraction Failed: {e}")
            return False


    def get_symbols(self) -> Set[Tuple[str, str, str]]:
        if not self._symbols_extracted and not self._symbols_attempted:
            self.parse(extract_symbols=True)

        return self.symbols


    def get_untyped_symbols(self) -> Dict[str, List[str]]:
        if not self._symbols_extracted and not self._symbols_attempted:
            self.parse(extract_symbols=True)

        return self.untyped_symbols


    def get_syntax_errors(self) -> List[ASTSyntaxError]:
        """
        Traverses the AST to extract granular syntax errors pinpointed 
        at the exact leaf node or missing token location.
        """

        if not self._ast_parsed:
            self.parse(extract_symbols=False)

        if not self.tree or not self.tree.root_node:
            self._log_warn("Unavailable Syntax Tree for Syntax Errors Inspection.")

            return []

        self._log_info("Inspecting Syntax Tree for Syntax Errors...")

        errors: List[ASTSyntaxError] = []
        error_counter = 1


        def find_leaf_errors(node: Node) -> List[Node]:
            if not node.children or node.is_missing:
                if node.is_missing or node.type == "ERROR" or (node.parent and node.parent.type == "ERROR"):
                    return [node]

                return []

            leaf_errors = []

            for child in node.children:
                leaf_errors.extend(find_leaf_errors(child))

            if not leaf_errors and (node.type == "ERROR" or node.is_missing):
                return [node]

            return leaf_errors


        def traverse(node: Node):
            nonlocal error_counter

            if node.is_missing or node.type == "ERROR":
                exact_err_nodes = find_leaf_errors(node)

                for err_node in exact_err_nodes:
                    token_text = err_node.text.decode('utf8') if err_node.text else ''
                    
                    if err_node.is_missing:
                        msg = f"Missing Token: '{err_node.type}'"
                    else:
                        msg = f"Unexpected Token '{token_text}'"

                    parent = err_node.parent

                    while parent and parent.type == "ERROR":
                        parent = parent.parent
                    
                    scope_name = f"{parent.type}_scope" if parent else "global"

                    errors.append(
                        ASTSyntaxError(
                            error_id=error_counter,
                            node_type=err_node.type,
                            scope_name=scope_name,
                            message=msg,
                            range=self._node_to_range(err_node),
                            node_text=token_text
                        )
                    )
                    error_counter += 1

                return

            for child in node.children:
                traverse(child)

        traverse(self.tree.root_node)

        if errors:
            self._log_warn(f"Found {len(errors)} Syntax Error(s).")
        else:
            self._log_info("No Syntax Errors Found.")

        return errors


    @staticmethod
    def _node_to_range(node: Node) -> ASTRange:
        """Converts a Tree-Sitter Node's spatial boundaries into an ASTRange instance."""

        return ASTRange(
            start_line=node.start_point[0] + 1,
            start_column=node.start_point[1],
            end_line=node.end_point[0] + 1,
            end_column=node.end_point[1],
            start_byte=node.start_byte,
            end_byte=node.end_byte
        )