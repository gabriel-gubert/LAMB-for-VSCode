import math
import re
from typing import List, Set, Optional, Any, Tuple

from lamb.core.logging import (
    log_info,
    log_warn,
    log_error
)
from lamb.core.types import (
    Complexity,
    ASTSyntaxError,
    ASTRange,
    EvaluationStatus,
    RuleConfidenceScore,
    ConfidenceLevel,
    GlobalConfidenceReport,
    GlobalDiagnostics,
    SnippetDiagnostics,
    TokenLogprob
)


class DynamicConfidenceEvaluator:
    """
    Computes global and rule-snippet granular confidence scores.
    Uses Tree-sitter syntax errors and SmartParser semantic symbols.
    """

    _PATH_SEPARATORS = re.compile(r"::|->|[./\\#]")
    _IDENTIFIER_RE = re.compile(r"\b[A-Za-z_]\w*\b")


    @classmethod
    def _norm_ns(cls, ns: str) -> str:
        return ".".join(s for s in cls._PATH_SEPARATORS.split(ns or "") if s)


    @staticmethod
    def _format_symbol(sym: Tuple[str, str, str]) -> str:
        return ".".join(filter(None, sym))


    @classmethod
    def _extract_snippet_tokens(cls, snippet: str) -> Set[str]:
        return set(cls._IDENTIFIER_RE.findall(snippet or ""))


    @staticmethod
    def _scope_symbols_to_snippet(
        symbols: Set[Tuple[str, str, str]],
        out_tokens: Set[str],
    ) -> Set[Tuple[str, str, str]]:
        """Filters whole-file semantic symbol tuples down to those referenced in output_snippet."""
        return {
            (s_ns, s_cls, s_mem)
            for (s_ns, s_cls, s_mem) in symbols
            if (
                (s_mem and s_mem in out_tokens)
                or (not s_mem and s_cls and s_cls in out_tokens)
                or (not s_mem and not s_cls and s_ns and all(seg in out_tokens for seg in s_ns.split(".")))
            )
        }


    @staticmethod
    def _symbol_matches_target(sym: Tuple[str, str, str], target: Tuple[str, str, str]) -> bool:
        """Checks whether an extracted (ns, cls, mem) tuple matches a rule target tuple."""
        s_ns, s_cls, s_mem = sym
        t_ns, t_cls, t_mem = target

        def ns_compatible(a: str, b: str) -> bool:
            return (
                a == b
                or a.startswith(f"{b}.")
                or b.startswith(f"{a}.")
                or a.endswith(f".{b}")
                or b.endswith(f".{a}")
            )

        if t_mem:
            if s_mem != t_mem:
                return False
            if s_cls and t_cls and s_cls != t_cls:
                return False
            if s_ns and t_ns and not ns_compatible(s_ns, t_ns):
                return False
            return True
        if t_cls:
            if s_mem or s_cls != t_cls:
                return False
            if s_ns and t_ns and not ns_compatible(s_ns, t_ns):
                return False
            return True
        if t_ns:
            return not s_mem and not s_cls and ns_compatible(s_ns, t_ns)
        return False


    @classmethod
    def _extract_rule_tuples(
        cls,
        applied_rule: Any,
    ) -> Tuple[Set[Tuple[str, str, str]], Set[Tuple[str, str, str]]]:
        """Extracts normalized (old_targets, new_targets) tuples from applied_rule.matches."""
        old_targets: Set[Tuple[str, str, str]] = set()
        new_targets: Set[Tuple[str, str, str]] = set()

        for m in getattr(applied_rule, "matches", []) or []:
            old_tup = (
                cls._norm_ns(getattr(m, "old_namespace", "") or ""),
                (getattr(m, "old_class_interface", "") or "").strip(),
                (getattr(m, "old_member", "") or "").strip(),
            )
            new_tup = (
                cls._norm_ns(getattr(m, "new_namespace", "") or ""),
                (getattr(m, "new_class_interface", "") or "").strip(),
                (getattr(m, "new_member", "") or "").strip(),
            )
            if any(old_tup):
                old_targets.add(old_tup)
            if any(new_tup):
                new_targets.add(new_tup)

        return old_targets, new_targets


    @classmethod
    def _extract_rule_symbols(cls, applied_rule: Any) -> Tuple[Set[str], Set[str]]:
        """
        Derives changed legacy tokens and expected target tokens strictly from the
        applied rule's MatchMapping entries so unchanged names are not flagged and
        coverage is not diluted by unrelated mapping table rows.
        """
        changed_old: Set[str] = set()
        expected_new: Set[str] = set()
        all_new_tokens: Set[str] = set()

        for m in getattr(applied_rule, "matches", []) or []:
            old_ns_segs = [s for s in cls._PATH_SEPARATORS.split(getattr(m, "old_namespace", "") or "") if s]
            new_ns_segs = [s for s in cls._PATH_SEPARATORS.split(getattr(m, "new_namespace", "") or "") if s]
            old_cls = (getattr(m, "old_class_interface", "") or "").strip()
            new_cls = (getattr(m, "new_class_interface", "") or "").strip()
            old_mem = (getattr(m, "old_member", "") or "").strip()
            new_mem = (getattr(m, "new_member", "") or "").strip()

            all_new_tokens.update(new_ns_segs)
            if new_cls:
                all_new_tokens.add(new_cls)
            if new_mem:
                all_new_tokens.add(new_mem)

            if new_mem:
                expected_new.add(new_mem)
            elif new_cls:
                expected_new.add(new_cls)
            elif new_ns_segs:
                expected_new.update((set(new_ns_segs) - set(old_ns_segs)) or set(new_ns_segs))

            if old_mem and old_mem != new_mem:
                changed_old.add(old_mem)
            if old_cls and old_cls != new_cls:
                changed_old.add(old_cls)
            if old_ns_segs and old_ns_segs != new_ns_segs:
                changed_old.update(set(old_ns_segs) - set(new_ns_segs))

        changed_old -= all_new_tokens
        return changed_old, expected_new


    @staticmethod
    def _dempster_combine(m1: float, m2: float) -> float:
        return m1 + m2 - (m1 * m2)


    @classmethod
    def _calculate_snippet_logprob_mass(
        cls, 
        snippet_range: ASTRange, 
        token_logprobs: Optional[List[TokenLogprob]]
    ) -> Tuple[float, int]:
        """
        Filters tokens that fall within the byte span of the rule's output snippet 
        and calculates snippet-specific logprob evidence mass using geometric mean.
        """

        if not token_logprobs:
            return 0.75, 0

        snippet_tokens = [
            t.logprob for t in token_logprobs
            if t.start_byte >= snippet_range.start_byte and t.end_byte <= snippet_range.end_byte
        ]

        if not snippet_tokens:
            return 0.75, 0

        geom_mean_prob = math.exp(sum(snippet_tokens) / len(snippet_tokens))

        return round(geom_mean_prob * 0.85, 3), len(snippet_tokens)


    @staticmethod
    def _ranges_overlap(r1: ASTRange, r2: ASTRange) -> bool:
        return not (r1.end_byte <= r2.start_byte or r1.start_byte >= r2.end_byte)


    @staticmethod
    def _locate_snippet_exact_range(migrated_code: str, snippet: str) -> Optional[ASTRange]:
        """
        Locates the exact byte, line, and column range of a snippet within migrated_code.
        Returns None if snippet does not exist in migrated_code (Divergence).
        """

        snippet_clean = snippet.strip()

        if not snippet_clean or snippet_clean not in migrated_code:
            return None

        # Byte offsets
        code_bytes = migrated_code.encode("utf8")
        snip_bytes = snippet_clean.encode("utf8")
        start_byte = code_bytes.find(snip_bytes)
        end_byte = start_byte + len(snip_bytes)

        # Line and Column offsets (1-indexed lines, 0-indexed columns)
        char_idx = migrated_code.find(snippet_clean)
        start_line = migrated_code[:char_idx].count('\n') + 1
        
        last_nl = migrated_code[:char_idx].rfind('\n')
        start_column = char_idx if last_nl == -1 else char_idx - (last_nl + 1)

        end_line = start_line + snippet_clean.count('\n')
        snip_last_nl = snippet_clean.rfind('\n')

        if snip_last_nl != -1:
            end_column = len(snippet_clean) - (snip_last_nl + 1)
        else:
            end_column = start_column + len(snippet_clean)

        return ASTRange(
            start_line=start_line,
            start_column=start_column,
            end_line=end_line,
            end_column=end_column,
            start_byte=start_byte,
            end_byte=end_byte
        )


    @classmethod
    def score_single_rule(
        cls,
        rule_mapping: dict,
        migrated_code: str,
        all_syntax_errors: List[ASTSyntaxError],
        old_symbols: Optional[Set[str]] = None,
        new_symbols: Optional[Set[str]] = None,
        retry_decay: float = 1.0,
        token_logprobs: Optional[List[TokenLogprob]] = None,
        migrated_symbols: Optional[Set[Tuple[str, str, str]]] = None,
        verbose: bool = True
    ) -> RuleConfidenceScore:
        """
        Evaluates an individual applied rule snippet directly against migrated_code.
        """

        rule_complexity = rule_mapping["applied_rule"].complexity
        is_deprecated = (
            rule_complexity == Complexity.DEPRECATED or 
            str(getattr(rule_complexity, "value", rule_complexity)).upper() == "DEPRECATED"
        )

        if not rule_mapping["output_snippet"] and is_deprecated:
            dep_range = ASTRange(
                start_line=1, start_column=0, end_line=1, end_column=0,
                start_byte=0, end_byte=0
            )
            dep_score = round(1.0 * retry_decay, 3)

            return RuleConfidenceScore(
                rule_id=rule_mapping["applied_rule"].rule_id,
                description=rule_mapping["applied_rule"].serialize() if hasattr(rule_mapping["applied_rule"], "serialize") and callable(rule_mapping["applied_rule"].serialize) else "",
                table_idxs=", ".join([str(match.table_idx) for match in rule_mapping["applied_rule"].matches]),
                operations=", ".join(rule_mapping["operations"]),
                range=dep_range,
                score=dep_score,
                level=ConfidenceLevel.HIGH if dep_score >= 0.85 else ConfidenceLevel.MEDIUM,
                status=EvaluationStatus.AUTO_APPROVED if dep_score >= 0.85 else EvaluationStatus.NEEDS_MANUAL_REVIEW,
                reason="",
                input_snippet=rule_mapping["input_snippet"],
                output_snippet="",
                diagnostics=SnippetDiagnostics(
                    leftover_legacy_symbols=[],
                    matched_target_symbols=[],
                    schema_coverage_ratio=1.0,
                    snippet_logprob_mass=1.0,
                    tokens_in_snippet=0
                )
            )

        snippet_range = cls._locate_snippet_exact_range(migrated_code, rule_mapping["output_snippet"])

        if not snippet_range:
            if verbose:
                log_info(f"Divergence for Rule #{rule_mapping['applied_rule'].rule_id}: Source Code Snippet `{rule_mapping['output_snippet'][:40]}...` Not Found in Migrated Code.")
            
            fallback_range = ASTRange(
                start_line=1, start_column=1, end_line=1, end_column=1,
                start_byte=0, end_byte=0
            )

            return RuleConfidenceScore(
                rule_id=rule_mapping["applied_rule"].rule_id,
                description=rule_mapping["applied_rule"].serialize() if hasattr(rule_mapping["applied_rule"], "serialize") and callable(rule_mapping["applied_rule"].serialize) else "",
                table_idxs=", ".join([str(match.table_idx) for match in rule_mapping["applied_rule"].matches]),
                operations=", ".join(rule_mapping["operations"]),
                range=fallback_range,
                score=0.0,
                level=ConfidenceLevel.ZERO,
                status=EvaluationStatus.REJECTED,
                reason="SOURCE CODE SNIPPET NOT FOUND",
                input_snippet=rule_mapping["input_snippet"],
                output_snippet=rule_mapping["output_snippet"],
                diagnostics=SnippetDiagnostics(
                    leftover_legacy_symbols=[],
                    matched_target_symbols=[],
                    schema_coverage_ratio=0.0,
                    snippet_logprob_mass=0.0,
                    tokens_in_snippet=0
                )
            )

        out_tokens = cls._extract_snippet_tokens(rule_mapping["output_snippet"])

        if migrated_symbols is not None and getattr(rule_mapping["applied_rule"], "matches", None):
            old_targets, new_targets = cls._extract_rule_tuples(rule_mapping["applied_rule"])
            snippet_symbols = cls._scope_symbols_to_snippet(migrated_symbols, out_tokens)

            matched_new_targets = {
                nt for nt in new_targets
                if any(cls._symbol_matches_target(sym, nt) for sym in snippet_symbols)
            }
            leftover_old_symbols = {
                sym for sym in snippet_symbols
                if any(cls._symbol_matches_target(sym, ot) for ot in old_targets)
                and not any(cls._symbol_matches_target(sym, nt) for nt in new_targets)
            }

            matched_targets = {cls._format_symbol(nt) for nt in matched_new_targets}
            leftover_legacy = {cls._format_symbol(sym) for sym in leftover_old_symbols}
            target_ratio = (len(matched_new_targets) / len(new_targets)) if new_targets else 1.0
        else:
            if getattr(rule_mapping["applied_rule"], "matches", None):
                changed_old, expected_new = cls._extract_rule_symbols(rule_mapping["applied_rule"])
            else:
                changed_old = old_symbols or set()
                expected_new = new_symbols or set()

            in_tokens = cls._extract_snippet_tokens(rule_mapping["input_snippet"])
            leftover_legacy = (in_tokens & changed_old) & out_tokens
            matched_targets = out_tokens & expected_new
            target_ratio = (len(matched_targets) / len(expected_new)) if expected_new else 1.0

        if leftover_legacy:
            legacy_ceiling = max(0.10, 0.40 - (len(leftover_legacy) * 0.15))
        else:
            legacy_ceiling = 1.0

        # Observer 1: Target Schema Compliance Ratio
        m1_schema = 0.85 * target_ratio

        # Observer 2: Granular Snippet Token Logprob Evidence Mass
        m2_logprob, token_count = cls._calculate_snippet_logprob_mass(
            snippet_range=snippet_range,
            token_logprobs=token_logprobs
        )

        # Dempster-Shafer Combination
        m_combined = cls._dempster_combine(m1_schema, m2_logprob)

        final_score = min(legacy_ceiling, m_combined * retry_decay)
        final_score = round(final_score, 3)

        if final_score >= 0.85:
            level = ConfidenceLevel.HIGH
            status = EvaluationStatus.AUTO_APPROVED
        elif final_score >= 0.60:
            level = ConfidenceLevel.MEDIUM
            status = EvaluationStatus.NEEDS_MANUAL_REVIEW
        else:
            level = ConfidenceLevel.LOW
            status = EvaluationStatus.FLAGGED

        syntax_errors = [
            err for err in all_syntax_errors
            if cls._ranges_overlap(err.range, snippet_range)
        ]

        if syntax_errors:
            error_messages = "\n".join([syntax_error.message for syntax_error in syntax_errors])

            if verbose:
                log_info(f"Syntax Error(s) in Rule #{rule_mapping['applied_rule'].rule_id} at {snippet_range}:\n\n{error_messages}\n\n")

            return RuleConfidenceScore(
                rule_id=rule_mapping["applied_rule"].rule_id,
                description=rule_mapping["applied_rule"].serialize() if hasattr(rule_mapping["applied_rule"], "serialize") and callable(rule_mapping["applied_rule"].serialize) else "",
                table_idxs=", ".join([str(match.table_idx) for match in rule_mapping["applied_rule"].matches]),
                operations=", ".join(rule_mapping["operations"]),
                range=snippet_range,
                score=0.0,
                level=ConfidenceLevel.ZERO,
                status=EvaluationStatus.REJECTED,
                reason="1 OR MORE SYNTAX ERROR(S)",
                input_snippet=rule_mapping["input_snippet"],
                output_snippet=rule_mapping["output_snippet"],
                diagnostics=SnippetDiagnostics(
                    syntax_errors=syntax_errors,
                    leftover_legacy_symbols=sorted(leftover_legacy),
                    matched_target_symbols=sorted(matched_targets),
                    schema_coverage_ratio=round(target_ratio, 3),
                    snippet_logprob_mass=m2_logprob,
                    tokens_in_snippet=token_count
                )
            )

        return RuleConfidenceScore(
            rule_id=rule_mapping["applied_rule"].rule_id,
            description=rule_mapping["applied_rule"].serialize() if hasattr(rule_mapping["applied_rule"], "serialize") and callable(rule_mapping["applied_rule"].serialize) else "",
            table_idxs=", ".join([str(match.table_idx) for match in rule_mapping["applied_rule"].matches]),
            operations=", ".join(rule_mapping["operations"]),
            range=snippet_range,
            score=final_score,
            level=level,
            status=status,
            reason="",
            input_snippet=rule_mapping["input_snippet"],
            output_snippet=rule_mapping["output_snippet"],
            diagnostics=SnippetDiagnostics(
                leftover_legacy_symbols=sorted(leftover_legacy),
                matched_target_symbols=sorted(matched_targets),
                schema_coverage_ratio=round(target_ratio, 3),
                snippet_logprob_mass=m2_logprob,
                tokens_in_snippet=token_count
            )
        )


    @classmethod
    def evaluate_migration_rules(
        cls,
        applied_rules: List[dict],
        migrated_code: str,
        all_syntax_errors: List[ASTSyntaxError],
        attempts_taken: int = 1,
        token_logprobs: Optional[List[TokenLogprob]] = None,
        migrated_symbols: Optional[Set[Tuple[str, str, str]]] = None,
        verbose: bool = True
    ) -> GlobalConfidenceReport:
        """
        Evaluates confidence scores strictly for applied rule snippets and overall code syntax.
        """

        retry_decay = max(0.60, 1.0 - ((attempts_taken - 1) * 0.10))

        rule_scores: List[RuleConfidenceScore] = []
        all_leftover_legacy: Set[str] = set()
        all_matched_targets: Set[str] = set()

        for rule in applied_rules:
            r_score = cls.score_single_rule(
                rule_mapping=rule,
                migrated_code=migrated_code,
                all_syntax_errors=all_syntax_errors,
                retry_decay=retry_decay,
                token_logprobs=token_logprobs,
                migrated_symbols=migrated_symbols,
                verbose=verbose
            )
            rule_scores.append(r_score)

            all_leftover_legacy.update(r_score.diagnostics.leftover_legacy_symbols)
            all_matched_targets.update(r_score.diagnostics.matched_target_symbols)

        reason = ""

        if all_syntax_errors:
            global_score = 0.0
            reason += "1 OR MORE SYNTAX ERROR(S) FOUND."
        elif not rule_scores:
            global_score = 1.0
        else:
            avg_score = sum(r.score for r in rule_scores) / len(rule_scores)

            if all_leftover_legacy:
                global_ceiling = max(0.10, 0.40 - (len(all_leftover_legacy) * 0.15))
                reason += "1 OR MORE LEFTOVER LEGACY SYMBOLS REMAIN."
            else:
                global_ceiling = 1.0

            global_score = min(global_ceiling, avg_score)

        global_score = round(global_score, 3)

        if global_score >= 0.85:
            global_level = ConfidenceLevel.HIGH
            global_status = EvaluationStatus.AUTO_APPROVED
        elif global_score >= 0.60:
            global_level = ConfidenceLevel.MEDIUM
            global_status = EvaluationStatus.NEEDS_MANUAL_REVIEW
        else:
            global_level = ConfidenceLevel.LOW
            global_status = EvaluationStatus.FLAGGED

        return GlobalConfidenceReport(
            score=global_score,
            level=global_level,
            status=global_status,
            reason=reason,
            rule_scores=rule_scores,
            diagnostics=GlobalDiagnostics(
                attempts_taken=attempts_taken,
                retry_penalty_factor=round(retry_decay, 2),
                total_rules_applied=len(rule_scores),
                total_syntax_errors=len(all_syntax_errors),
                syntax_errors=all_syntax_errors,
                leftover_legacy_symbols=sorted(all_leftover_legacy),
                matched_target_symbols=sorted(all_matched_targets)
            )
        )