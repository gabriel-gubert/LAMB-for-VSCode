from enum import Enum
from typing import List, Literal, Optional

from pydantic import BaseModel, Field

import tree_sitter_language_pack as tslp


class APIElement(BaseModel):
    namespace: str = Field(default="", description="Namespace, package, or module name.")
    class_or_interface: str = Field(default="", description="Class, Interface, or Struct name.")
    member: str = Field(default="", description="Method, function, property, or constant name.")
    signature: str = Field(default="", description="Full signature (e.g., param types, return type, URL path).")
    summary: str = Field(default="", description="Brief description of behavior.")


class ElementsExtraction(BaseModel):
    elements: List[APIElement]


class MappingRow(BaseModel):
    old_namespace: str = Field(default="")
    old_class_interface: str = Field(default="")
    old_member: str = Field(default="")
    old_signature: str = Field(default="")
    new_namespace: str = Field(default="")
    new_class_interface: str = Field(default="")
    new_member: str = Field(default="")
    new_signature: str = Field(default="")
    complexity: str = Field(default="")
    additional_notes: str = Field(
        default="", 
        description="Markdown compliant notes for complex migrations or deprecations. Empty if direct match."
    )


class ResolvedItem(BaseModel):
    v1_element: APIElement = Field(
        ..., 
        description="The original legacy element being evaluated."
    )
    selected_targets: List[APIElement] = Field(
        default_factory=list, 
        description=(
            "The selected target(s). 1 item for 1:1 or N:1. "
            "Multiple items for 1:N or N:N. "
            "Top 3 choices for ambiguous mappings. Empty list if deprecated."
        )
    )
    reason: str = Field(
        default="", 
        description=(
            "Detailed Markdown notes explaining why specific target elements "
            "were selected for the legacy element. For each item in "
            "selected_targets, the model must provide at least one valid technical reason for its "
            "inclusion in the final mapping."
        )
    )


class ResolutionResult(BaseModel):
    resolved_items: List[ResolvedItem]


class DirectoryDiscovery(BaseModel):
    directories: List[str] = Field(
        ...,
        description="List of absolute paths to directories most likely to contain API reference documentation or source code."
    )


def get_supported_languages() -> list[str]:
    if hasattr(tslp, "manifest_languages"):
        languages = list(tslp.manifest_languages())
        if languages:
            return sorted(set(languages))
    return sorted(set(tslp.available_languages()))


AvailableLanguages = Enum(
    "AvailableLanguages",
    {lang: lang for lang in get_supported_languages()}
)

class Language(BaseModel):
    language: AvailableLanguages = Field(
        description="The target programming language identifier supported by tree-sitter."
    )


class SymbolIdentifier(BaseModel):
    namespace: str = Field(
        default="",
        description="Inferred namespace, package, or module path using dot notation (e.g., 'Database.Core', 'java.util', 'pandas'). Empty string if global or unknown."
    )
    class_or_interface: str = Field(
        default="",
        description="Class, interface, struct, trait, or enum name (e.g., 'QueryEngine', 'Vector2', 'DataFrame'). Empty string for standalone functions/constants, namespace-only references, or when the receiver's type is unknown."
    )
    member: str = Field(
        default="",
        description="Method, function, property, field, constant, or enum variant name (e.g., 'executeQuery', 'y', 'shape'). Empty string if referencing the container or namespace itself."
    )


class UntypedSymbolUsage(BaseModel):
    symbol_name: str = Field(
        description="Name of an undeclared/external variable or untyped parameter whose type cannot be determined from the snippet."
    )
    accessed_members: List[str] = Field(
        default_factory=list,
        description="All attributes, properties, and methods accessed on this symbol (e.g., ['get_collider', 'apply_impulse'])."
    )


class ParserResult(BaseModel):
    identifiers: List[SymbolIdentifier] = Field(
        default_factory=list,
        description="All API namespaces, types/containers, standalone symbols, and member usages referenced in the code snippet."
    )
    untyped_symbols: List[UntypedSymbolUsage] = Field(
        default_factory=list,
        description="Undeclared/external variables or untyped parameters whose type is unknown, along with the members accessed on each."
    )


class RefactoringStep(BaseModel):
    step_number: int = Field(description="Sequential step number.")
    title: str = Field(description="Short title of the refactoring step.")
    description: str = Field(description="Detailed explanation of code changes.")
    cardinality: Literal["1:1", "1:N", "N:1", "N:N"] = Field(description="Mapping type applied.")
    target_symbols: List[str] = Field(description="Symbols or functions affected by this step.")


class MigrationPlanSchema(BaseModel):
    overview: str = Field(description="High-level architectural summary of the migration.")
    steps: List[RefactoringStep] = Field(description="Ordered refactoring steps.")

RefactoringOperation = Literal[
    # Class & Interface Changes
    "RENAME_CLASS",
    "RENAME_INTERFACE",
    "MOVE_CLASS",
    "EXTRACT_INTERFACE",
    "INLINE_CLASS",
    
    # Method & Function Changes
    "RENAME_METHOD",
    "MOVE_METHOD",
    "CHANGE_SIGNATURE",
    "ADD_PARAMETER",
    "REMOVE_PARAMETER",
    "REORDER_PARAMETERS",
    "CHANGE_RETURN_TYPE",
    "EXTRACT_METHOD",
    "INLINE_METHOD",

    # Symbol, Variable & Field Changes
    "RENAME_SYMBOL",
    "RENAME_FIELD",
    "CHANGE_FIELD_TYPE",
    "REPLACE_VARIABLE",
    "EXTRACT_VARIABLE",
    "INLINE_VARIABLE",

    # Module & Import/Namespace Changes
    "RENAME_NAMESPACE",
    "MOVE_MODULE",
    "UPDATE_IMPORT",

    # Syntax, Expression & Construct Changes
    "REPLACE_EXPRESSION",
    "REPLACE_CONSTRUCT",
    "WRAP_WITH_TRY_CATCH",
    "CONVERT_CALLBACK_TO_ASYNC",

    # Deprecation & Removal Handlings
    "DEPRECATION_REMOVAL",
    "REPLACE_DEPRECATED_API",
    "NO_OP"
]

class AppliedRuleMapping(BaseModel):
    rule_id: int = Field(
        default=-1,
        description="The unique numerical ID of the migration rule that was applied."
    )
    operations: List[RefactoringOperation] = Field(
        default_factory=lambda: ["RENAME_SYMBOL"],
        description="The list of refactoring operations performed by this rule."
    )
    input_snippet: str = Field(
        default="",
        description="The exact snippet or line from the legacy source code affected by this rule."
    )
    output_snippet: str = Field(
        default="",
        description="The exact transformed snippet or line generated in the migrated code by this rule."
    )


class MigrationOutputSchema(BaseModel):
    migrated_code: str = Field(
        default="", 
        description="The complete, valid, executable refactored code without markdown code block fences."
    )
    applied_rules: List[AppliedRuleMapping] = Field(
        default_factory=list, 
        description="Granular mappings tracking each applied rule ID alongside its source input snippet and transformed output snippet."
    )