"""LAMB: LLM-Assisted Code Migration Bot."""

from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import Any

try:
    __version__ = version("lamb")
except PackageNotFoundError:
    __version__ = "1.0.0"

_LAZY_EXPORTS: dict[str, tuple[str, str]] = {
    "ConfigManager": ("lamb.config.manager", "ConfigManager"),
    "ConfigSchema": ("lamb.config.schema", "ConfigSchema"),
    "RegistryManager": ("lamb.config.registry", "RegistryManager"),
    "RateLimitedChatOpenAI": ("lamb.llm.rate_limited", "RateLimitedChatOpenAI"),
    "RateLimitedOpenAIEmbeddings": ("lamb.llm.rate_limited", "RateLimitedOpenAIEmbeddings"),
    "Mapper": ("lamb.mapping.mapper", "Mapper"),
    "anchor_exact_matches": ("lamb.mapping.anchoring", "anchor_exact_matches"),
    "Migrator": ("lamb.migration.migrator", "Migrator"),
    "SmartParser": ("lamb.migration.parser", "SmartParser"),
    "DynamicConfidenceEvaluator": ("lamb.migration.confidence", "DynamicConfidenceEvaluator"),
    "create_openai_component": ("lamb.factory", "create_openai_component"),
    "mapper_agent": ("lamb.factory", "mapper_agent"),
    "migrator_agent": ("lamb.factory", "migrator_agent"),
}

__all__ = ["__version__", *_LAZY_EXPORTS.keys()]


def __getattr__(name: str) -> Any:
    if name in _LAZY_EXPORTS:
        module_path, attr_name = _LAZY_EXPORTS[name]
        module = import_module(module_path)
        return getattr(module, attr_name)
    raise AttributeError(f"module 'lamb' has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(__all__)
